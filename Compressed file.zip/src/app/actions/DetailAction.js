'use strict';

import Reflux from 'reflux';

const DetailAction = Reflux.createActions([
  'getInfo'
]);

export default DetailAction;