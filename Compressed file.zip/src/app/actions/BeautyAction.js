'use strict';

import Reflux from 'reflux';

const BeautyAction = Reflux.createActions([
  'getAll',
  'getMore'
]);

export default BeautyAction;