'use strict';

import Reflux from 'reflux';

const HotWordsAction = Reflux.createActions([
  'changeItem'
]);

export default HotWordsAction;