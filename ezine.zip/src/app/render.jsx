'use strict';

import React from "react";
import app_routes from './app_router';

React.render(app_routes, document.body);